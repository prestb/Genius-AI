"use client";

import Link from "next/link";
import { useState } from "react";
import { ArrowLeft, BrainCircuit, ShieldCheck, Sparkles } from "lucide-react";

type AnalysisResponse = { symbol: string; interval: string; model: string; latestCandleAt: string; candleAgeSeconds: number; generatedAt: string; analysis: string; disclaimer: string; error?: string };
const intervals = ["1min", "5min", "15min", "30min", "1h", "4h", "1day"];

export default function AISignalLabPage() {
  const [symbol, setSymbol] = useState("EUR/USD");
  const [interval, setInterval] = useState("15min");
  const [question, setQuestion] = useState("Compare the bullish and bearish technical scenarios. Identify the strongest evidence, key uncertainties, and what would invalidate each scenario. Do not invent news or price levels.");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<AnalysisResponse | null>(null);

  async function runAnalysis() {
    setLoading(true); setError(""); setResult(null);
    try {
      const response = await fetch("/api/ai-analysis", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ symbol, interval, question }) });
      const data = await response.json();
      if (!response.ok) throw new Error(typeof data.error === "string" ? data.error : "Analysis request failed.");
      setResult(data as AnalysisResponse);
    } catch (caught) { setError(caught instanceof Error ? caught.message : "Analysis request failed."); }
    finally { setLoading(false); }
  }

  return <main className="app-shell"><section className="main-panel"><header className="topbar"><div className="breadcrumb"><Link href="/">Dashboard</Link><span className="crumb-slash">/</span><strong>AI Signal Lab</strong></div><span className="status-pill"><ShieldCheck size={13}/> Signals only · No order execution</span></header>
    <div className="content"><div className="welcome-row"><div><div className="eyebrow"><span className="eyebrow-line"/>RESEARCH ASSISTANT</div><h1>AI <span className="title-period">Signal Lab</span></h1><p className="subtitle">AI-assisted interpretation of fresh market candles. This is an explanatory second opinion, not a verified signal.</p></div><Link href="/" className="secondary-button"><ArrowLeft size={14}/> Dashboard</Link></div>
      <div className="demo-alert"><div className="alert-icon"><ShieldCheck size={17}/></div><div><strong>Signals-only safety boundary</strong><span>This app cannot place, modify, or cancel live orders. AI output never triggers execution.</span></div></div>
      <section className="panel" style={{ padding: 22, marginBottom: 18 }}><div className="section-heading"><div><h2><BrainCircuit size={17} style={{ display: "inline", verticalAlign: "middle", marginRight: 8 }}/>Ask about the market</h2><p>The server retrieves fresh candles; API keys remain server-side.</p></div><Sparkles size={20}/></div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(180px,1fr))", gap: 14, marginBottom: 14 }}><label style={{ display: "grid", gap: 7, fontSize: 12, color: "var(--muted)" }}>Symbol<input value={symbol} onChange={e => setSymbol(e.target.value)} maxLength={30} placeholder="EUR/USD" style={{ background: "var(--panel2)", color: "var(--text)", border: "1px solid var(--border)", borderRadius: 8, padding: 12 }}/></label><label style={{ display: "grid", gap: 7, fontSize: 12, color: "var(--muted)" }}>Timeframe<select value={interval} onChange={e => setInterval(e.target.value)} style={{ background: "var(--panel2)", color: "var(--text)", border: "1px solid var(--border)", borderRadius: 8, padding: 12 }}>{intervals.map(item => <option key={item} value={item}>{item}</option>)}</select></label></div>
        <label style={{ display: "grid", gap: 7, fontSize: 12, color: "var(--muted)" }}>Research question<textarea value={question} onChange={e => setQuestion(e.target.value)} maxLength={1200} rows={4} style={{ background: "var(--panel2)", color: "var(--text)", border: "1px solid var(--border)", borderRadius: 8, padding: 12, resize: "vertical" }}/></label>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, marginTop: 14, flexWrap: "wrap" }}><small style={{ color: "var(--muted)" }}>Uses up to 60 recent candles. Stale data is rejected.</small><button className="primary-button" type="button" onClick={() => void runAnalysis()} disabled={loading || !symbol.trim() || !question.trim()}>{loading ? "Analyzing…" : "Analyze market"}</button></div>
      </section>
      {error && <div role="alert" className="demo-alert"><div className="alert-icon">!</div><div><strong>Analysis unavailable</strong><span>{error}</span></div></div>}
      {result && <section className="panel" style={{ padding: 22, marginBottom: 18 }}><div className="section-heading"><div><h2>{result.symbol} · {result.interval}</h2><p>Latest candle: {result.latestCandleAt} UTC · {result.candleAgeSeconds}s old · Model: {result.model}</p></div><span className="status-pill">AI research</span></div><div style={{ whiteSpace: "pre-wrap", lineHeight: 1.8, fontSize: 13 }}>{result.analysis}</div><p style={{ color: "var(--muted)", fontSize: 11, borderTop: "1px solid var(--border)", paddingTop: 14, marginTop: 20 }}>{result.disclaimer}</p></section>}
      <footer className="backtest-footer"><span>GENIUS TRADING WEB · AI RESEARCH</span><span>Explanatory analysis only · No broker connection · No live orders</span></footer>
    </div></section></main>;
}
