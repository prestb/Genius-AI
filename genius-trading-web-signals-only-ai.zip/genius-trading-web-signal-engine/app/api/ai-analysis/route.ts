import { NextRequest, NextResponse } from "next/server";
import { isValidCandle } from "@/lib/market-validation";

export const dynamic = "force-dynamic";
export const revalidate = 0;

const allowedIntervals = new Set(["1min", "5min", "15min", "30min", "1h", "4h", "1day"]);
const systemPrompt = `You are an assistant for a SIGNALS-ONLY trading research dashboard. You do not execute trades and must never suggest that you can place, modify, or cancel orders. Analyze only the supplied validated OHLC candle context. Do not invent current prices, news, indicators, fundamentals, or facts not present in the input. Clearly state that OHLC-only context is limited and that this is not a prediction or financial advice. If evidence is mixed or insufficient, say so. You may discuss bullish, bearish, or neutral scenarios, levels directly grounded in supplied candles, risk factors, and what evidence would invalidate each scenario. Never guarantee returns, state unsupported win probabilities, or present an AI conclusion as a verified deterministic signal. Keep the response structured with: Summary; Evidence; Bullish scenario; Bearish scenario; Risks and uncertainty; What to watch next.`;

type Candle = { time: string; open: number; high: number; low: number; close: number };

export async function POST(request: NextRequest) {
  const apiKey = process.env.OPENAI_API_KEY;
  const marketKey = process.env.TWELVE_DATA_API_KEY;
  if (!apiKey) return NextResponse.json({ error: "AI analysis is not configured. Add OPENAI_API_KEY to the server environment." }, { status: 503 });
  if (!marketKey) return NextResponse.json({ error: "Market data is not configured. Add TWELVE_DATA_API_KEY to the server environment." }, { status: 503 });

  let body: { symbol?: unknown; interval?: unknown; question?: unknown };
  try { body = await request.json(); } catch { return NextResponse.json({ error: "Request body must be valid JSON." }, { status: 400 }); }
  const symbol = typeof body.symbol === "string" ? body.symbol.trim() : "";
  const interval = typeof body.interval === "string" ? body.interval : "";
  const question = typeof body.question === "string" ? body.question.trim() : "Give a balanced technical overview of this market.";
  if (!/^[A-Za-z0-9_./-]{1,30}$/.test(symbol)) return NextResponse.json({ error: "Invalid market symbol." }, { status: 400 });
  if (!allowedIntervals.has(interval)) return NextResponse.json({ error: "Unsupported timeframe." }, { status: 400 });
  if (question.length > 1200) return NextResponse.json({ error: "Question must be 1,200 characters or fewer." }, { status: 400 });

  try {
    const params = new URLSearchParams({ symbol, interval, timezone: "UTC", outputsize: "80", apikey: marketKey });
    const marketResponse = await fetch(`https://api.twelvedata.com/time_series?${params}`, { cache: "no-store", signal: AbortSignal.timeout(12000) });
    if (!marketResponse.ok) return NextResponse.json({ error: "Market-data provider request failed." }, { status: 502 });
    const marketBody = await marketResponse.json();
    if (marketBody.status === "error" || !Array.isArray(marketBody.values)) return NextResponse.json({ error: "Validated market candles are unavailable for this request." }, { status: 502 });
    const candles = (marketBody.values as Record<string, unknown>[]).map((item): Candle => ({
      time: String(item.datetime ?? ""), open: Number(item.open), high: Number(item.high), low: Number(item.low), close: Number(item.close),
    })).filter((candle) => isValidCandle(candle) && Number.isFinite(Date.parse(candle.time))).sort((a, b) => Date.parse(a.time) - Date.parse(b.time));
    if (candles.length < 30) return NextResponse.json({ error: "Insufficient validated candles for useful analysis." }, { status: 502 });
    const latest = candles[candles.length - 1];
    const ageSeconds = Math.max(0, Math.floor((Date.now() - Date.parse(latest.time)) / 1000));
    const intervalSeconds: Record<string, number> = { "1min": 60, "5min": 300, "15min": 900, "30min": 1800, "1h": 3600, "4h": 14400, "1day": 86400 };
    const isFresh = ageSeconds <= intervalSeconds[interval] * 2;
    if (!isFresh) return NextResponse.json({ error: `Latest candle is stale (${ageSeconds}s old). Refresh later; AI analysis is blocked on stale data.` }, { status: 409 });

    const model = process.env.OPENAI_MODEL || "gpt-4.1-mini";
    const aiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST", cache: "no-store", signal: AbortSignal.timeout(30000),
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({ model, temperature: 0.2, max_completion_tokens: 1000, messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: JSON.stringify({ symbol, interval, latestCandleAt: latest.time, candleAgeSeconds: ageSeconds, candles: candles.slice(-60), question }) },
      ] }),
    });
    if (!aiResponse.ok) {
      const status = aiResponse.status;
      return NextResponse.json({ error: status === 401 ? "OpenAI rejected the API key. Check server configuration." : status === 429 ? "AI provider rate limit or quota reached. Try later or check API billing." : "AI provider request failed." }, { status: status === 429 ? 429 : 502 });
    }
    const aiBody = await aiResponse.json();
    const analysis = aiBody?.choices?.[0]?.message?.content;
    if (typeof analysis !== "string" || !analysis.trim()) return NextResponse.json({ error: "AI provider returned an empty or unsupported response." }, { status: 502 });
    return NextResponse.json({ symbol, interval, model, latestCandleAt: latest.time, candleAgeSeconds: ageSeconds, generatedAt: new Date().toISOString(), analysis: analysis.trim(), disclaimer: "AI-assisted research only. Not a verified trading signal, prediction, or financial advice. No orders are placed by this application." });
  } catch (error) {
    const message = error instanceof Error && error.name === "TimeoutError" ? "The market-data or AI request timed out. Try again." : "AI analysis is temporarily unavailable.";
    return NextResponse.json({ error: message }, { status: 502 });
  }
}
