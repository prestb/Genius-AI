import { afterEach, describe, expect, it } from "vitest";
import { NextRequest } from "next/server";
import { POST } from "../app/api/ai-analysis/route";

const originalOpenAIKey = process.env.OPENAI_API_KEY;
const originalMarketKey = process.env.TWELVE_DATA_API_KEY;
afterEach(() => {
  if (originalOpenAIKey === undefined) delete process.env.OPENAI_API_KEY; else process.env.OPENAI_API_KEY = originalOpenAIKey;
  if (originalMarketKey === undefined) delete process.env.TWELVE_DATA_API_KEY; else process.env.TWELVE_DATA_API_KEY = originalMarketKey;
});

function request(body: unknown) {
  return new NextRequest("http://localhost/api/ai-analysis", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
}

describe("AI analysis API request guards", () => {
  it("fails closed when the OpenAI key is missing", async () => {
    delete process.env.OPENAI_API_KEY;
    process.env.TWELVE_DATA_API_KEY = "test-market-key";
    const response = await POST(request({ symbol: "EUR/USD", interval: "15min" }));
    expect(response.status).toBe(503);
    expect((await response.json()).error).toContain("OPENAI_API_KEY");
  });

  it("fails closed when the market-data key is missing", async () => {
    process.env.OPENAI_API_KEY = "test-openai-key";
    delete process.env.TWELVE_DATA_API_KEY;
    const response = await POST(request({ symbol: "EUR/USD", interval: "15min" }));
    expect(response.status).toBe(503);
    expect((await response.json()).error).toContain("TWELVE_DATA_API_KEY");
  });

  it("rejects invalid symbols before making provider requests", async () => {
    process.env.OPENAI_API_KEY = "test-openai-key";
    process.env.TWELVE_DATA_API_KEY = "test-market-key";
    const response = await POST(request({ symbol: "EUR/USD;DROP", interval: "15min" }));
    expect(response.status).toBe(400);
    expect((await response.json()).error).toContain("Invalid market symbol");
  });

  it("rejects unsupported intervals and oversized prompts", async () => {
    process.env.OPENAI_API_KEY = "test-openai-key";
    process.env.TWELVE_DATA_API_KEY = "test-market-key";
    const intervalResponse = await POST(request({ symbol: "EUR/USD", interval: "3min" }));
    expect(intervalResponse.status).toBe(400);
    const promptResponse = await POST(request({ symbol: "EUR/USD", interval: "15min", question: "x".repeat(1201) }));
    expect(promptResponse.status).toBe(400);
  });
});
