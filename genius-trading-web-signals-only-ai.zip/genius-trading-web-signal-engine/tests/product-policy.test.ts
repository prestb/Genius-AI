import { describe, expect, it } from "vitest";
import { assertSignalsOnlyPolicy, PRODUCT_CAPABILITIES } from "../lib/product-policy";

describe("signals-only product boundary", () => {
  it("keeps all live execution capabilities disabled", () => {
    expect(PRODUCT_CAPABILITIES.signalsOnly).toBe(true);
    expect(PRODUCT_CAPABILITIES.liveOrderExecution).toBe(false);
    expect(PRODUCT_CAPABILITIES.brokerConnection).toBe(false);
    expect(PRODUCT_CAPABILITIES.automaticSignalExecution).toBe(false);
    expect(assertSignalsOnlyPolicy()).toBe(true);
  });

  it("allows research and simulated paper trading only", () => {
    expect(PRODUCT_CAPABILITIES.paperTradingSimulation).toBe(true);
    expect(PRODUCT_CAPABILITIES.aiMarketExplanation).toBe(true);
  });
});
