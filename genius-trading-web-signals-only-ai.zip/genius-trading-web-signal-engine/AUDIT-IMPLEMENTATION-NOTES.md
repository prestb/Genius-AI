# Audit implementation notes

## Included changes

- Backtest engine version bumped to 1.2.0.
- Position sizing now estimates round-trip spread, slippage and fees at the planned stop, and scales P/L and fees using a configurable contract/P&L multiplier.
- Added a separate conservative OHLC-based intrabar maximum drawdown metric; the existing close-marked maximum drawdown remains available.
- Added approximate missing-candle interval count and largest observed candle gap to backtest period metadata and UI.
- Added regression tests for intrabar drawdown, missing intervals, invalid multipliers, and multiplier handling.
- Added explanatory warnings and README documentation for instrument-specification limitations, gap risk, historical data coverage, local-only paper trading/experiment storage, AI workflow status, and disabled live execution.

## Verification status

- Source-level review and TypeScript parser pass: the compiler reported no syntax errors after the test-file brace correction.
- Full TypeScript typecheck, Vitest, ESLint, and production build were **not completed** because dependency installation (`npm ci`) timed out and left an incomplete `node_modules` directory in the execution environment. Remove `node_modules` and run `npm ci` in a network-enabled environment before running the quality gates.
- Do not interpret the included changes as production-certified or as evidence of strategy profitability.

## Explicitly not implemented

- Durable server-side paper-trading or experiment storage. This needs a selected database/authentication design and migration plan.
- AI-generated analysis workflow. An environment-variable placeholder alone is not an AI implementation.
- Live broker order submission, persistent idempotency, order lifecycle, execution reconciliation, or a server-side emergency-stop service. Live trading remains disabled.
- Broker-specific contract size, tick/pip value, leverage, and account-currency conversion inference. Supply the correct multiplier for the instrument; `1` is only a neutral default, not a universal specification.

## Signals-only boundary and AI Signal Lab update

- Added `/ai-signal-lab` and `POST /api/ai-analysis`. The server fetches recent Twelve Data candles, validates them, rejects stale latest candles, and sends at most 60 candles to the OpenAI Chat Completions API for explanatory research. OpenAI keys are read only from server environment variables. `OPENAI_MODEL` is optional and defaults to `gpt-4.1-mini`.
- Added AI endpoint tests for missing provider keys, invalid symbols/timeframes, and oversized prompts. These tests do not call external providers.
- Added a product capability contract and tests that explicitly keep broker connections, live order execution, and automatic signal execution disabled.
- Removed the live-trading readiness link from primary navigation. The legacy route now documents the permanent signals-only policy. Paper trading remains a local simulation only.
- Existing signal-analysis tests exercise deterministic BUY/SELL/WAIT conditions, invalid/stale data, risk plans, and optional regime/price-action confirmation. Those are implementation tests, not evidence of profitability.
- Verification status for this archive: dependencies could not be fully installed in the current environment, so the full Vitest, TypeScript, ESLint, and production-build gates remain unverified. Run `npm ci`, `npm test`, `npx tsc --noEmit`, `npm run lint`, and `npm run build` in Codespaces before rollout.
