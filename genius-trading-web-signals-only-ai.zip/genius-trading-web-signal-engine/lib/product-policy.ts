/** Product-level capability contract: this app provides research and simulation only. */
export const PRODUCT_CAPABILITIES = Object.freeze({
  signalsOnly: true,
  liveOrderExecution: false,
  brokerConnection: false,
  automaticSignalExecution: false,
  paperTradingSimulation: true,
  aiMarketExplanation: true,
} as const);

export function assertSignalsOnlyPolicy(): true {
  if (PRODUCT_CAPABILITIES.liveOrderExecution || PRODUCT_CAPABILITIES.brokerConnection || PRODUCT_CAPABILITIES.automaticSignalExecution) {
    throw new Error("Signals-only policy violated: live execution capabilities must remain disabled.");
  }
  return true;
}
